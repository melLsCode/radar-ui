import * as THREE from 'https://unpkg.com/three@0.152.2/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.152.2/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'https://unpkg.com/three@0.152.2/examples/jsm/loaders/GLTFLoader.js';



const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 1, 3);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;

const light = new THREE.PointLight(0xffffff, 1);
light.position.set(3, 3, 3);
scene.add(light);

let scanLine, model;
let scanning = false;
let scanY = -1.5;
let direction = 1;

// Glowing scan line
const scanGeometry = new THREE.PlaneGeometry(1.5, 0.02);
const scanMaterial = new THREE.MeshBasicMaterial({
  color: 0x00ff00,
  transparent: true,
  opacity: 0.7
});
scanLine = new THREE.Mesh(scanGeometry, scanMaterial);
scene.add(scanLine);

// Load 3D model (glb)
const loader = new GLTFLoader();
loader.load(
  'human.glb', // Replace with your own GLB file if needed
  (gltf) => {
    model = gltf.scene;
    model.scale.set(1.2, 1.2, 1.2);
    model.position.y = -1.2;
    scene.add(model);
  },
  undefined,
  (error) => {
    console.error('Model load error:', error);
  }
);

function animate() {
  requestAnimationFrame(animate);

  if (model && scanning) {
    model.rotation.y += 0.01;
    scanY += direction * 0.03;

    if (scanY > 1.5 || scanY < -1.5) {
      direction *= -1;
      playBeep();
    }

    scanLine.position.y = scanY;
  }

  controls.update();
  renderer.render(scene, camera);
}
animate();

function startScan() {
  scanning = true;
  document.getElementById('status').textContent = 'SCANNING';
  document.getElementById('status').style.color = 'lime';
  playBeep();
}

function stopScan() {
  scanning = false;
  document.getElementById('status').textContent = 'IDLE';
  document.getElementById('status').style.color = 'gray';
  scanLine.position.y = -1.5;
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('startScanBtn').addEventListener('click', startScan);
  document.getElementById('stopScanBtn').addEventListener('click', stopScan);
});

function playBeep() {
  const beep = document.getElementById('beep');
  beep.currentTime = 0;
  beep.play();
}

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
